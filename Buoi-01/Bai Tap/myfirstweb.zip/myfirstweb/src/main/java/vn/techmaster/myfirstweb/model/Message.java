package vn.techmaster.myfirstweb.model;

public record Message (String title, String content) {
  
}
