package vn.techmaster.myfirstweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyfirstwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyfirstwebApplication.class, args);
	}

}
