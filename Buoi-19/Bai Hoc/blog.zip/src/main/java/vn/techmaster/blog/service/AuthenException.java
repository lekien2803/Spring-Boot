package vn.techmaster.blog.service;

public class AuthenException extends Exception {
  private static final long serialVersionUID = -5456969534529937512L;

  public AuthenException(String message) {
    super(message);
  }
  
}