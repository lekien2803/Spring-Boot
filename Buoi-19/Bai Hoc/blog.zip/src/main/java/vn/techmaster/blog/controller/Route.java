package vn.techmaster.blog.controller;

public class Route {  
  public static final String LOGIN_TEMPLATE = "login.html";  
  public static final String REDIRECT_POSTS = "redirect:/posts";
  public static final String HOME = "home.html";
  public static final String REDIRECT_HOME = "redirect:/";
  public static final String ALLPOSTS = "posts.html";
  public static final String POST = "post.html";
  public static final String POST_COMMENT = "post_comment.html";
  public static final String SEARCH = "search";
  public static final String SEARCH_RESULT = "searchresult";
}